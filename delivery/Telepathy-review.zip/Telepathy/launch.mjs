import {fork,spawn} from "node:child_process";
import {once} from "node:events";
import {fileURLToPath} from "node:url";
import {dirname,join} from "node:path";
const home=dirname(fileURLToPath(import.meta.url));
const [major,minor]=process.versions.node.split(".").map(Number);
if(major<22||(major===22&&minor<13))throw Error("Install Node 22.13 or later before starting this rehearsal.");
const port=Number(process.argv[2]||5827);
if(!Number.isInteger(port)||port<1||port>65535)throw Error("Choose a port from 1 to 65535.");
const url="http://127.0.0.1:"+port+"/cinema.html";
let already=false;
try{const response=await fetch(url,{signal:AbortSignal.timeout(500)});already=response.ok&&(await response.text()).includes('data-telepathy="rehearsal"');}catch{}
let hub;
if(!already){
 hub=fork(join(home,"web/rehearsal.mjs"),[join(home,"hub-runtime"),String(port)],{stdio:["inherit","inherit","inherit","ipc"],windowsHide:true});
 await Promise.race([once(hub,"message"),once(hub,"exit").then(([code])=>{throw Error("Rehearsal startup failed ("+code+"). Check the port and hub dependencies.");})]);
}
console.log("Cinema "+url+"\nStage http://127.0.0.1:"+port+"/studio-stage.html");
if(!process.env.TELEPATHY_NO_OPEN){
 const [bin,args]=process.platform==="win32"?["rundll32.exe",["url.dll,FileProtocolHandler",url]]:process.platform==="darwin"?["open",[url]]:["xdg-open",[url]];
 const opener=spawn(bin,args,{detached:true,stdio:"ignore",windowsHide:true});opener.on("error",()=>{});opener.unref();
}
if(hub){
 const stop=()=>{if(hub.connected)hub.send("stop");};
 for(const sig of ["SIGINT","SIGTERM"])process.once(sig,stop);
 await once(hub,"exit");
}

